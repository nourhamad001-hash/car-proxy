# Car Proxy Server

Proxy server between the car dashboard and Roboflow HC-SR04 detection API.

## API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | Check server status |
| `/detect` | POST | Detect HC-SR04 in image |

## /detect Request

```json
POST /detect
Content-Type: application/json

{
  "image": "<base64 encoded JPEG>"
}
```

## /detect Response

```json
{
  "command": "FORWARD",
  "target_found": false,
  "reason": "HC-SR04 centered (87%) — moving closer",
  "confidence": 0.87,
  "bbox": {
    "x": 0.2,
    "y": 0.3,
    "w": 0.15,
    "h": 0.12
  },
  "count": 1
}
```

## Commands returned

| Command | Meaning |
|---|---|
| FORWARD | Drive forward toward sensor |
| LEFT | Turn left — sensor is on left |
| RIGHT | Turn right — sensor is on right |
| TARGET_FOUND | Sensor close — stop the car |
| STOP | Error or timeout — stop for safety |

## Deploy to Railway

1. Push this repo to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add environment variable: `ROBOFLOW_API_KEY` = your key
4. Get your domain from Settings → Domains

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ROBOFLOW_API_KEY` | Yes | Your Roboflow private API key |
| `PORT` | Auto | Set by Railway automatically |
